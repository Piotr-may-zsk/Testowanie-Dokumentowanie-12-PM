/**
 * Sprawdza czy wiek jest większy niż 18 lat
 * @param age {number} age of person
 * @returns {boolean} Is adult or not
 * @throws {Error} When age is lower than 0
 * @author Piotr May 5D
 *
 */

function isAdult(age) {
    if (age >= 18) {
        return true
    }
    else if (age > 0) {
        return false
    }
    else{
        throw new Error("Age must be greater than 0")
    }
}