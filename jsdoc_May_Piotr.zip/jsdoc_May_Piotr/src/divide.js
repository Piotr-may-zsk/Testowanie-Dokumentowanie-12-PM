/**
 * Funkcja służy do dzielenia dwóch liczb
 * @param a {number} First number
 * @param b {number} Divider
 * @returns {number} Result
 * @throws {Error} When divider is 0
 * @author Piotr May 5D
 *
 * @example
 * const a = 10
 * const b = 5
 *
 * const result = divide(a, b)
 * console.log(result);
 * // Logs: 2
 */

function divide(a, b) {
    if (a != 0){
        return a / b;
    } else {
        throw new Error("Can't divide by 0")
    }
}