/**
 * Wita użytkownika na stronie
 * @param somebody {string} Name of person
 * @returns {void} None
 * @author Piotr May 5D
 */

const sayHello = (somebody) => {
    alert(`Hello ${somebody}`);
};