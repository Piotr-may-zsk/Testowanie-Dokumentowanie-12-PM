/**
 * Obliczanie pola koła
 * @param radius {number} - Promień
 * @throws {Error} When radius is lower or equal 0
 * @returns {number} pole koła
 * @author Piotr May 5D
 */

function circleArea(radius){
    if (radius >= 0){
        return Math.round(Math.PI * Math.pow(radius, 2));
    } else {
        throw new Error('radius must be greater than 0')
    }
}